import express from "express";
import cors from "cors";
import * as bip39 from "bip39";
import * as bip32 from "bip32";
import * as bitcoin from "bitcoinjs-lib";
import { ethers, HDNodeWallet } from "ethers";
import TronWeb from "tronweb";
import {
  Keypair,
  Connection,
  PublicKey,
} from "@solana/web3.js";
import axios from "axios";

const app = express();
app.use(cors());
app.use(express.json());

const pathMap = {
  btc: "m/84'/0'/0'/0",
  ltc: "m/84'/2'/0'/0",
  eth: "m/44'/60'/0'/0",
  bnb: "m/44'/60'/0'/0",
  usdt: "m/44'/60'/0'/0",
  trx: "m/44'/195'/0'/0",
  sol: "m/44'/501'/0'/0'"
};

const usdtContracts = {
  eth: "0xdAC17F958D2ee523a2206206994597C13D831ec7",
  bnb: "0x55d398326f99059fF775485246999027B3197955",
  trx: "TXYZopYRdj2D9XRtbG411XZZ3kM5VkAeBf"
};

// All route handlers...

const port = process.env.PORT || 3000;
app.listen(port, () => console.log("Wallet API running on port", port));
